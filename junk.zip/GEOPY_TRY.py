# import the geocoding services you'd like to try
# NOMINATIM requires no key
from geopy.geocoders import ArcGIS, Bing, Nominatim, OpenCage
from keys import bing_key


# GeocoderDotUS inactivated for error
# OpenMapQuest  inactivated for error
# GoogleV3
import csv, sys

print ('creating geocoding objects!')
arcgis = ArcGIS(timeout=100)
bing = Bing('your-API-key', timeout=100)
nominatim = Nominatim(user_agent='ippy_geo', timeout=100)
opencage = OpenCage('your-API-key', timeout=100)
# geocoderDotUS = GeocoderDotUS(timeout=100)
# googlev3 = GoogleV3(timeout=100)
# openmapquest = OpenMapQuest(timeout=100)

# choose and order your preference for geocoders here
geocoders = [Bing, Nominatim, ArcGIS]

def geocode(address):
    i = 0
    try:
        while i < len(geocoders):
            # try to geocode using a service
            location = geocoders[i].geocode(address)

            # if it returns a location
            if location != None:

                # return those values
                return [location.latitude, location.longitude]
            else:
                # otherwise try the next one
                i += 1
    except:
        # catch whatever errors, likely timeout, and return null values
        print(sys.exc_info()[0])
        return ['null', 'null']

    # if all services have failed to geocode, return null values
    return ['null', 'null']


print('geocoding addresses!')

# list to hold all rows
dout = []

with open('C:/OPTMODELS/ZIPGEO/data/data.csv') as fin:
    reader = csv.reader(fin)
    j = 0
    for row in reader:
        print ("processing #", j)
        j += 1
        try:
            # configure this based upon your input CSV file
            street = row[2]
            city = row[3]
            state = row[4]
            postalcode = row[5]
            country = row[6]
            address = street + ", " + city + ", " + state + " " + postalcode + " " + country
            print(address)
            result = geocode(address)
            # add the lat/lon values to the row
            row.extend(result)
            print(result)

            # add the new row to master list
            dout.append(row)
        except:
            print('the better you look the more you see')

print('writing the results to file')

# print results to file
with open('C:/OPTMODELS/ZIPGEO/output/geopy_try_geocoded.csv', 'w') as fout:
    writer = csv.writer(fout)
    writer.writerows(dout)

print('all done!')
