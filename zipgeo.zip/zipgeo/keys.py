##keys.py
# User Agent identification (e.g., email address) for Nominatim
# (Querying without user agent is against ToS)
n_user = 'ippy_geo_SeanTMac'

# Bing API key
bing_key = 'AoJJuYV8QP9lu9YBLEZm73yStVpT3N-mLfFIF50O9bry_ke5lkIsFxLohMxGbDmi'

# OpenCage API key
oc_key = '7779311'

# GoogleV3 API key
# g3_key = ''

# OpenMapQuest API key
# omq_key =''