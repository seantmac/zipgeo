from geopy.geocoders import Nominatim, Bing
import csv, sys

bing = Bing('AoJJuYV8QP9lu9YBLEZm73yStVpT3N-mLfFIF50O9bry_ke5lkIsFxLohMxGbDmi',timeout=100)
nominatim = Nominatim(user_agent='ippy_geo_SeanTMac', timeout=100)

##BING
##ApplicationName ippy_geo
##Key	            AoJJuYV8QP9lu9YBLEZm73yStVpT3N-mLfFIF50O9bry_ke5lkIsFxLohMxGbDmi
##KeySubtypeText	Dev/Test
##KeyTypeText     Basic



# choose and order your preference for geocoders here
geocoders = [bing, nominatim]


def geocode(address):
    i = 0
    try:
        while i < len(geocoders):
            # try to geocode using a service
            location = geocoders[i].geocode(address)

            # if it returns a location
            if location != None:

                # return those values
                return [location.latitude, location.longitude]
            else:
                # otherwise try the next one
                i += 1
    except:
        # catch whatever errors, likely timeout, and return null values
        print
        sys.exc_info()[0]
        return ['null', 'null']

    # if all services have failed to geocode, return null values
    return ['null', 'null']


print
'geocoding addresses!'

# list to hold all rows
dout = []

with open('C:/OPTMODELS/ZIPGEO/data/kents_fiber_facs.csv', mode='r') as fin:
    reader = csv.reader(fin)
    j = 0
    for row in reader:
        j += 1
        try:
            # configure this based upon your input CSV file
            street = row[2]
            city = row[3]
            state = row[4]
            postalcode = row[5]
            country = row[6]
            address = street + ", " + city + ", " + state + " " + postalcode + " " + country
            print(address)
            result = geocode(address)
            # add the lat/lon values to the row
            row.extend(result)
            print(result)
            # add the new row to master list
            dout.append(row)
        except:
            print('the better you look the more you see')

print('writing the results to file')

# print results to file
with open('C:/OPTMODELS/ZIPGEO/output/geocoded.csv', 'w') as fout:
    writer = csv.writer(fout)
    writer.writerows(dout)

print('all done!')